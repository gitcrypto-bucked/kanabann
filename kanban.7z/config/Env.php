<?php
declare(strict_types=1);
namespace config;
ini_set('allow_url_fopen','1');
date_default_timezone_set('America/Sao_Paulo');
define("ROOT", dirname(__DIR__,2).DIRECTORY_SEPARATOR);  
header("Access-Control-Allow-Origin: *");


class Env
{

    const DOMAIN = 'http://localhost';

    const FOLDER ='kanban';

    const DIR =ROOT.self::FOLDER;


    const URL = self::DOMAIN.'/'.self::FOLDER;
    
    const DATABASE_DRIVER ='mysql';

    const DB_HOST ='127.0.0.1';

    const DB_NAME ='Kanban';

    const DB_USER ='dev';

    const DB_PASSWORD ='fast9002';

    const RESULTS_PER_PAGE = 18;

    const SESSION = 3; //time in hours

    const DEBUG = false;

    public static function getAssets()
    {
        return self::getServer().'/'.self::FOLDER.'/'."views".'/'."assets";
    }

    private static function getServer()
    {
        $protocol = (!empty($_SERVER['HTTPS']) && (strtolower($_SERVER['HTTPS']) == 'on' || $_SERVER['HTTPS'] == '1')) ? 'https://' : 'http://';
        $port = $_SERVER['SERVER_PORT'] ? ':'.$_SERVER['SERVER_PORT'] : '';
        return $protocol.$_SERVER['SERVER_NAME'].$port;
    }

    public static function getURL()
    {
        return self::getServer().'/'.self::FOLDER;
    }


}