<?php

namespace db;

abstract class Database  
{  
    abstract protected function connect() ;  
    abstract protected function disconnect() ; 
}  


?>