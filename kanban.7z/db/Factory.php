<?php

namespace db;

use config\Env;

class Factory extends Database
{
    public function __construct()
    {
        $this->connect();
    }

    public function __destruct()
    {
        $this->disconnect();
    }
    
    protected function connect()
    {
        $dsn = 'mysql:host=' . Env::DB_HOST . ';dbname=' . Env::DB_NAME . ';charset=utf8';
        try 
        {
            $this->conn = new \PDO($dsn, Env::DB_USER, Env::DB_PASSWORD);
        } 
        catch (\PDOException $e) 
        {
            throw new \Exception($e->getMessage(), $e->getCode());
            exit;
        }
        $this->conn->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
    }

    protected function disconnect()
    {
        $this->conn = null;
    }

    public function insert($table, $fields, $values, array $params)
    {
        $SQL ='INSERT INTO '.$table.' ('.$fields.') VALUES ('.$values.')';
        $stmt = $this->conn->prepare($SQL);
        if($stmt->execute($params)==true)
        {
            return true;
        }
        else return false;
    }

    public function getAll($table,  $params='*', $order='', $limit='')
    {
       $SQL = 'SELECT ';
       $SQL.= strlen($params) ? $params : ' * ';
       $SQL.= ' FROM '.$table;
       $SQL.= strlen($order) ? ' ORDER BY '.$order : '';
       $SQL.= strlen($limit) ? ' Limit'.$limit : '';

        $stmt = $this->conn->query($SQL);
        $result =  $stmt ->fetchAll(\PDO::FETCH_ASSOC);       
        return $result;
    }

    public function get($table,  $params='*', $where='' ,$order='', $limit='')
    {
        $SQL = 'SELECT ';
        $SQL.= strlen($params) ? $params : ' * ';
        $SQL.= ' FROM '.$table;
        $SQL.= strlen($where) ? ' WHERE '.$where : '';
        $SQL.= strlen($order) ? ' ORDER BY '.$order : '';
        $SQL.= strlen($limit) ? ' Limit'.$limit : '';
        $stmt = $this->conn->query($SQL);
        $result =  $stmt ->fetchAll(\PDO::FETCH_ASSOC);       
        return $result;
    }

    public function getJoin($table,  $params='*', $where='', $join, $on)
    {
        $SQL = 'SELECT ';
        if(stripos($params,',')!=false)
        {
            $list = explode(',',$params);
            for($i=0; $i<sizeof($list);$i++)
            {
                if(($i+1)==sizeof($list))
                {
                    $SQL.= 't1.'.$list[$i].' ';
                }
                else 
                {
                    $SQL.= 't1.'.$list[$i].', ';
                }
            }
         
        }
        else
        {
            $SQL.= strlen($params) ? $params : '*';
        }
        $SQL.= ' FROM '.$table.' as t1 ';
        $SQL.= ' JOIN '.$join.' as t2';
        $SQL.=' ON t1.'.$on.'='.'t2.'.$on;
        $SQL.= strlen($where) ? ' WHERE '."t1.".$where : '';

        $stmt = $this->conn->query($SQL);
        $result =  $stmt ->fetchAll(\PDO::FETCH_ASSOC);       
        return $result;
    }
    
    public function update($table, $fileds, $where, array $params)
    {
        $SQL='UPDATE '.$table.' SET '.$fileds.' WHERE '.$where;
        $stmt = $this->conn->prepare($SQL);  
        if($stmt->execute($params)==true)
        {
            return true;
        }
        else return false;
    }


    private $conn;

}
?>