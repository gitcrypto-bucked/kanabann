<?php
namespace app\model;

use \db\Factory;

class userModel extends \db\Factory
{
    public function __construct()
    {
        parent::connect();
    }

    public function get($table,  $params='*', $where='' ,$order='', $limit='')
    {
        return parent::get($table,  $params='*', $where='' ,$order='', $limit='');
    }
}


?>