<?php
namespace app\model;

use \db\Factory;

class KanbanModel extends \db\Factory
{
    public function __construct()
    {
        parent::connect();
    }

    public function get($table,  $params='*', $where='' ,$order='', $limit='')
    {
        return parent::get($table,  $params, $where ,$order, $limit);
    }

    public function getJoin($table,  $params='*', $where='', $join, $on)
    {
        return parent::getJoin($table,  $params, $where, $join, $on);
    }

    public function insert($table, $fields, $values, array $params)
    {
        return parent::insert($table, $fields, $values,  $params);
    }

    public function update($table, $fileds, $where, array $params)
    {
        return parent::update($table, $fileds, $where,  $params);
    }


    
}


?>