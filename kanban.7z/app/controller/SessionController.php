<?php

namespace app\controller;

use app\model\UserModel;

use \config\Env;


class SessionController extends Controller
{
    protected function before()
    {
    }

    public function newSession($user)
    {
        $cookie_name = "user";
        $cookie_value = $user[0]['nome'];
        setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
        if(isset($_SESSION['uid']))
        {
            session_regenerate_id();
            unset($_SESSION['uid']);
        }
        $_SESSION['uid'] = session_id();
        $_SESSION['uuid'] = $user[0]['id'];
        $_SESSION['password'] = $user[0]['senha'];
        $_SESSION['email']=  $user[0]['email'];
        $_SESSION['name'] =  $user[0]['nome'];
        $_SESSION['inicio'] = date('H:i');
        $_SESSION['ativa'] = 'true';
        $_SESSION['data'] = date('Y-m-d');
        $_SESSION['role'] = $user[0]['role'];
        $_SESSION['groupID'] = $user[0]['groupID'];
        $time = Env::SESSION;
		$end = date('H:i', strtotime($_SESSION['inicio'] .'+'.$time.' hour'));
        $_SESSION['fim'] = $end ;
        return true;
    }

    public function destroySession()
    {
        if(isset($_SESSION['uid']))
        {
            session_unset();
            session_destroy();
        }
    }


    protected function after()
    {
        $this->model = null;
    }


    private $model;

}