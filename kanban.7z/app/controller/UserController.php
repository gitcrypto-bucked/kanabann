<?php

namespace app\controller;

use app\model\UserModel;

use \config\Env;

use app\controller\SessionController;

class UserController extends Controller
{
    protected function before()
    {
        if($_SERVER['REQUEST_METHOD']!='POST')
        {
            http_response_code(303);
        }
        if(!isset($$_REQUEST['token']))
        {
            http_response_code(303);
        }
    }

    
    public function loginPage()
    {
       include Env::DIR."/views/home/index.php";
    }

    public function userLogin()
    {
        $email = $_REQUEST['uname'];
        $password = $_REQUEST['psw'];
        
        $model = new UserModel();
        $user = $model->get('users',' * ',"email='".$email.'" AND ativo="1"','','' );
        if(sizeof($user)== 0 | empty($user))
        {
            $_SESSION['flask_message']= 'Usuario/Senha Invalida!';
            self::loginPage();
            exit;   
        }
        if(password_verify($password, $user[0]['senha']))
        {
            $sess = new SessionController();
            if($sess->newSession($user))
            {
                header('Location: ./dash');
            }
            
        }
        
    }

    public function logout()
    {
        $sess = new SessionController();
        $sess->destroySession();
        $_SESSION['flask_message']= 'Logout realizado com sucesso!';
        self::loginPage();
        exit;   
    }

    protected function after()
    {

    }
}


?>