<?php

namespace app\controller;

use \config\Env;

class Home extends Controller
{

    protected function before()
    {
        if($_SERVER['REQUEST_METHOD']!='GET')
        {
            http_response_code(303);
        }
    }


    public function indexPage()
    {
        require_once  Env::DIR."/views/home/index.php";
    }

    protected function after()
    {

    }
}


?>