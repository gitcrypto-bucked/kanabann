<?php

namespace app\controller;

use app\model\KanbanModel;

use \config\Env;

use SessionController;
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Origin: *');

class KanbanController extends Controller
{
    protected function before()
    {
        $this->model = new KanbanModel();
    }

    public function dashPage()
    {
        include Env::DIR."/views/dash/index.php";
    }

    
    protected function after()
    {
    }

    public function getGroupPersons($group)
    {
        $this->before();
        return $this->model->getJoin('users',  $params='nome, id ', $where='groupID="'.$group.'"', $join='grupos', $on='groupID');
    }

    public function getToDoWork($userID)
    {
        $this->before();
        return $this->model->get($table='projetos',  $params='*', $where='userID="'.$userID.'" AND todo="1" AND aproved="0"' ,$order='', $limit='');
    }

    public function getOngoinWork($userID)
    {
        $this->before();
        return $this->model->get($table='projetos',  $params='*', $where='userID="'.$userID.'" AND ongoing="1" AND aproved="0"' ,$order='', $limit='');
    }

    public function getDoneWork($userID)
    {
        $this->before();
        return $this->model->get($table='projetos',  $params='*', $where='userID="'.$userID.'" AND done="1" AND aproved="0"' ,$order='', $limit='');
    }

    public function getTestingWork($userID)
    {
        $this->before();
        return $this->model->get($table='projetos',  $params='*', $where='userID="'.$userID.'" AND testing="1" AND aproved="0"' ,$order='', $limit='');
    }

    public function getGoneWork($userID)
    {
        $this->before();
        return $this->model->get($table='projetos',  $params='*', $where='userID="'.$userID.'"  AND aproved="1"' ,$order='', $limit='');
    }

    public function newTask()
    {
        $this->before();

        $userID = $_REQUEST['atribuido'];
        $groupID = $_REQUEST['groupID'];
        $titulo = $_REQUEST['title'];
        $tarefa = $_REQUEST['tarefa'];
        $comentarios = $_REQUEST['comentarios'];

        $todo='1';
        $ongoing='0';
        $done ='0';
        $testing='0';
        $aproved='0';

        $target_file= null;

        $target_dir = dirname(__DIR__,2).DIRECTORY_SEPARATOR.'public'.DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR;

        if(isset($_FILES) & !empty($_FILES))
        {           
            $target_file = $target_dir . basename($_FILES["taanexorefa"]["name"]);

            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" )
            {
                $_SESSION['flask_message'] = 'O arquivo deve ser JPG, JPEG, PNG & PDF';
                header("Location: ./dash");
                exit;
            }

            if (move_uploaded_file($_FILES["taanexorefa"]["tmp_name"], $target_file)) 
            {
                $target_file ='public'."/".'uploads'."/".  basename($_FILES["taanexorefa"]["name"]);
            }
            else
            {
                $_SESSION['flask_message'] = 'Houve um erro ao salvar o arquivo';
                header("Location: ./dash");
                exit;
            }        
        }
        if($this->model->insert('projetos', 'titulo, tarefa, dataHoraCadastro,
                                             todo, ongoing, done, testing, groupID,
                                             userID, comentarios, aproved, anexos', 
                                            ' ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? ',
                                             [$titulo, $tarefa, date("Y-m-d H:i:s"), 
                                            $todo, $ongoing, $done, $testing, $groupID,
                                             intval($userID), $comentarios, $aproved, $target_file])==true)
        {
            $_SESSION['flask_message'] = 'Tarefa salva com sucesso';
            header("Location: ./dash");
            exit;
        }
       

    }


    public function updateTask()
    {
        $this->before();
        if(empty($_POST))
        {
            $_POST =  json_decode(file_get_contents('php://input'), true);
            if(isset($_POST['fn']) & $_POST['fn']=='update')
            {
                switch($_POST['status'])
                {
                    case 'todo':
                         $_POST['todo'] ='1';
                         $_POST['ongoing'] ='0';
                         $_POST['done'] ='0';
                         $_POST['testing'] ='0';
                         $_POST['aproved'] ='0';
                    break;
                    case 'ongoing':
                         $_POST['todo'] ='0';
                         $_POST['ongoing'] ='1';
                         $_POST['done'] ='0';
                         $_POST['testing'] ='0';
                         $_POST['aproved'] ='0';
                    break;
                    case 'done':
                         $_POST['todo'] ='0';
                         $_POST['ongoing'] ='0';
                         $_POST['done'] ='1';
                         $_POST['testing'] ='0';
                         $_POST['aproved'] ='0';
                    break;
                    case 'testing':
                        $_POST['todo'] ='0';
                        $_POST['ongoing'] ='0';
                        $_POST['done'] ='0';
                        $_POST['testing'] ='1';
                        $_POST['aproved'] ='0';
                   break;
                    case 'aproved':
                         $_POST['todo'] ='0';
                         $_POST['ongoing'] ='0';
                         $_POST['done'] ='0';
                         $_POST['testing'] ='0';
                         $_POST['aproved'] ='1';
                    break;
                }
                if($this->model->update('projetos','todo=?, ongoing=? , done=?, testing=? ,aproved=?', ' uid=?',
                [$_POST['todo'] , $_POST['ongoing'], $_POST['done'] , $_POST['testing'],$_POST['aproved'], $_POST['uid'] ] )==true)
                {
                    echo 202; exit;
                }
            }    
        }
    }

    private $model;
}

?>