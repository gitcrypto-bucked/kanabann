<?php

use \config\Env;
use \helpers\Helper;
use \app\controller\KanbanController;


$controller = new KanbanController();
$group = $controller->getGroupPersons($userID=$_SESSION['groupID']);


$todo = $controller->getToDoWork($userID=$_SESSION['uuid']);
$ongoing =$controller->getOngoinWork($userID=$_SESSION['uuid']);
$done = $controller->getDoneWork($userID=$_SESSION['uuid']);
$testing = $controller->getTestingWork($userID=$_SESSION['uuid']);
$gone = $controller->getGoneWork($userID=$_SESSION['uuid']);


?>
<!DOCTYPE php>
<html lang="pt" >
<head>
<meta charset="UTF-8">
<title> Kanban Board</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/icon?family=Material+Icons'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Arbutus+Slab'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.0/spectrum.min.css'>
<link rel="stylesheet" href="<?php echo Env::getAssets(); ?>/style.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<style>
    .btn
    {
        outline:none;
        border:0px;
    }

    .w3-button:hover
    {
        font-weight:550 !important;
        color:white !important;
    }

    .nav-link
    {
        padding-top:18px !important;
    }

</style>

</head>
<body>
    
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="javascript:void(0)"><img src="<?php echo Env::getAssets(); ?>/logo/logo-lowcost-branco.svg" width="170" alt=''></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mynavbar">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link" href="<?=strlen(@$_SESSION['uuid'])?'./dash':'./' ?>">Home</a>
        </li>
      
        <li class="nav-item">
            <a class="nav-link"><?=Helper::greetings() ?><span class='text-white'><?php echo $_SESSION['name'];?></span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style='width:150px'></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./logout">Sair</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style='width:50px'></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="javascript:void(0)">
                <button class="viewkanban btn btn-primary"><i class=" material-icons ">view_column</i></button>
            </a>           
        </li>
        
        <li class="nav-item d-flex">
            <a class="nav-link" href="javascript:void(0)">
                <button class="viewlist btn btn-primary"><i class="material-icons">view_list</i></button>
            </a>
        </li>
      </ul>
     
    </div>
  </div>
</nav>

<div class="container-fluid mt-3">
    <div class='row'>
        <div id="p1" class="mdl-progress mdl-js-progress"></div>
        <script>
            document.querySelector('#p1').addEventListener('mdl-componentupgraded', function() {
                this.MaterialProgress.setProgress(44);
            });
        </script>       
    </div>
    <form  method='GET' id='user'  action="./dash">
        <ul class="list-group list-group-horizontal-md mt-3 mb-3 " style='padding-left:50px'>       
                <?php
                    for($i=0; $i< sizeof($group); $i++)
                    {
                        echo '<li class="list-group-item">
                                    <button type="button" name="userID" class="btn btn-primary"  onclick="getUser('.$group[$i]['id'].')" id="'.$group[$i]['id'].'" " value="'.$group[$i]['id'].'"">'.$group[$i]['nome'].'</button></li>';
                    }

                ?>      
        </ul>
    </form>
</div>

<div class="container-fluid mt-3">
    <div class='row'>
            <!-- -->
         
            <div class="dd row" id="main" name='main'>
            <?php 
                
                if($_SESSION['flask_message']!='')
                {
                    echo '<p class="alert alert-danger" role="alert" id="flask">'.$_SESSION['flask_message'].'</p>' ;
                    $_SESSION['flask_message']='';
                }
            ?>
            <!-- kanban to do -->
            <ol class="kanban To-do" id='todo' name='todo'>
                <div class="kanban__title">
                    <h3><i class="material-icons">report_problem</i> A fazer</h3>
                </div>
                <!-- to do list -->
                <?php 
                if(empty($todo))
                {
                    echo '<li class="dd-item" data-id="0"  id="0" name="0">
                        <h4 class="title dd-handle"><i class=" material-icons ">filter_none</i> Sem tarefas</h4>
                        <div class="text" contenteditable="false"></div>
                        <div class="actions">
                        </div>
                    </li>';
                }
                else
                {
                    for($i=0; $i<count($todo); $i++)
                    {
                        echo '<li class="dd-item" data-id="'.$todo[$i]['uid'].'" id="'.$todo[$i]['uid'].'"  name="'.$todo[$i]['uid'].'">
                                    <p class=" dd-handle"><i class=" material-icons ">filter_none</i> '.$todo[$i]['titulo'].' </p>
                                    <div class="text" contenteditable="false" >'.$todo[$i]['tarefa'].'</div>
                                    <div><img src="'.($todo[$i]['anexos']).'" width="180"></div>
                                    <div class="actions">                                    
                                    <i class="material-icons" id="label blue">label</i><div class="actions">
                                    <i class="material-icons" id="color">palette</i><i class="material-icons">edit</i>
                                    <i class="material-icons">insert_link</i><i class="material-icons">attach_file</i></div>
                                </li>';
                    }
                }
                ?>
                <!--to do list end -->
                <?php
                    if($_SESSION['role']=='admin')
                    {
                        echo '<div class="actions">
                                <button class="addbutt" data-bs-toggle="modal" data-bs-target="#myModal"><i class="material-icons">control_point</i> Nova</button>
                            </div>';
                    }
                ?>
            </ol>
            <!--kanban ongoing -->
            <ol class="kanban progress" id='ongoing' name='ongoing'>
                <h3><i class="material-icons">build</i>Em andamento</h3>
                <!--start -->
                <?php 
                    if(empty($ongoing))
                    {
                        echo '<li class="dd-item" data-id="0" id="0" name="0" >
                            <h4 class="title dd-handle"><i class=" material-icons ">filter_none</i> Sem tarefas</h4>
                            <div class="text" contenteditable="false"></div>
                            <div class="actions">
                            </div>
                        </li>';
                    }
                    else
                    {
                        for($i=0; $i<count($ongoing); $i++)
                        {
                            echo '<li class="dd-item" data-id="'.$ongoing[$i]['uid'].'" id="'.$ongoing[$i]['uid'].'"  name="'.$ongoing[$i]['uid'].'">
                                        <p class=" dd-handle"><i class=" material-icons ">filter_none</i> '.$ongoing[$i]['titulo'].' </p>
                                        <div class="text" contenteditable="false" >'.$ongoing[$i]['tarefa'].'</div>
                                        <div><img src="'.($ongoing[$i]['anexos']).'" width="180"></div>
                                        <div class="actions">                                    
                                        <i class="material-icons" id="label blue">label</i><div class="actions">
                                        <i class="material-icons" id="color">palette</i><i class="material-icons">edit</i>
                                        <i class="material-icons">insert_link</i><i class="material-icons">attach_file</i></div>
                                    </li>';
                        }
                    }
                ?>
                <!--start --> 
                <!-- <div class="actions">
                <button class="addbutt" onclick='createOngoing()'><i class="material-icons">control_point</i>Nova</button>
                </div> -->
            </ol>
            <!--- kanban gone -->
            <ol class="kanban Done" id="done" name="done">
                <h3><i class="material-icons">check_circle</i> Feitos</h3>
                <?php 
                    if(empty($done))
                    {
                        echo '<li class="dd-item" data-id="0" id="0" name="0" >
                            <h4 class="title dd-handle"><i class=" material-icons ">filter_none</i> Sem tarefas</h4>
                            <div class="text" contenteditable="false"></div>
                            <div class="actions">
                            </div>
                        </li>';
                    }
                    else
                    {
                        for($i=0; $i<count($done); $i++)
                        {
                            echo '<li class="dd-item" data-id="'.$done[$i]['uid'].'" id="'.$done[$i]['uid'].'"  name="'.$done[$i]['uid'].'">
                                        <p class=" dd-handle"><i class=" material-icons ">filter_none</i> '.$done[$i]['titulo'].' </p>
                                        <div class="text" contenteditable="false" >'.$done[$i]['tarefa'].'</div>
                                        <div><img src="'.($done[$i]['anexos']).'" width="180"></div>
                                        <div class="actions">                                    
                                        <i class="material-icons" id="label blue">label</i><div class="actions">
                                        <i class="material-icons" id="color">palette</i><i class="material-icons">edit</i>
                                        <i class="material-icons">insert_link</i><i class="material-icons">attach_file</i></div>
                                    </li>';
                        }
                    }
                ?>
                <!-- <div class="actions">
                <button class="addbutt" onclick='createDone()'><i class="material-icons">control_point</i>Nova</button>
                </div> -->
            </ol>
                    <!-- kanban testing-->
                <ol class="kanban Testing" id="testing" name="testing">
                    <h3><i class="material-icons">delete</i> Testando</h3>
                    <?php 
                    if(empty($testing))
                    {
                        echo '<li class="dd-item" data-id="0" id="0" name="0" >
                            <h4 class="title dd-handle"><i class=" material-icons ">filter_none</i> Sem tarefas</h4>
                            <div class="text" contenteditable="false"></div>
                            <div class="actions">
                            </div>
                        </li>';
                    }
                    else
                    {
                        for($i=0; $i<count($testing); $i++)
                        {
                            echo '<li class="dd-item" data-id="'.$testing[$i]['uid'].'" id="'.$testing[$i]['uid'].'"  name="'.$testing[$i]['uid'].'">
                                        <p class=" dd-handle"><i class=" material-icons ">filter_none</i> '.$testing[$i]['titulo'].' </p>
                                        <div class="text" contenteditable="false" >'.$testing[$i]['tarefa'].'</div>
                                        <div><img src="'.($testing[$i]['anexos']).'" width="180"></div>
                                        <div class="actions">                                    
                                        <i class="material-icons" id="label blue">label</i><div class="actions">
                                        <i class="material-icons" id="color">palette</i><i class="material-icons">edit</i>
                                        <i class="material-icons">insert_link</i><i class="material-icons">attach_file</i></div>
                                    </li>';
                        }
                    }
                ?>
                <!-- <div class="actions">
                    <button class="addbutt"  onclick="createGone()"><i class="material-icons">control_point</i> Nova</button>
                </div> -->
                </ol>
            <!-- kanban gone-->
                <ol class="kanban Gone" id="gone" name="gone">
                    <h3><i class="material-icons">delete</i> Encerradas</h3>
                    <?php 
                        if(empty($gone))
                        {
                            echo '<li class="dd-item" data-id="0" id="0" name="0" >
                                <h4 class="title dd-handle"><i class=" material-icons ">filter_none</i> Sem tarefas</h4>
                                <div class="text" contenteditable="false"></div>
                                <div class="actions">
                                </div>
                            </li>';
                        }
                        else
                        {
                            for($i=0; $i<count($gone); $i++)
                            {
                                echo '<li class="dd-item" data-id="'.$gone[$i]['uid'].'" id="'.$gone[$i]['uid'].'"  name="'.$gone[$i]['uid'].'">
                                            <p class=" dd-handle"><i class=" material-icons ">filter_none</i> '.$gone[$i]['titulo'].' </p>
                                            <div class="text" contenteditable="false" >'.$gone[$i]['tarefa'].'</div>
                                            <div><img src="'.($gone[$i]['anexos']).'" width="180"></div>
                                            <div class="actions">                                    
                                            <i class="material-icons" id="label blue">label</i><div class="actions">
                                            <i class="material-icons" id="color">palette</i><i class="material-icons">edit</i>
                                            <i class="material-icons">insert_link</i><i class="material-icons">attach_file</i></div>
                                        </li>';
                            }
                        }
                ?>
                <!-- <div class="actions">
                    <button class="addbutt"  onclick="createGone()"><i class="material-icons">control_point</i> Nova</button>
                </div> -->
                </ol>
              
            </div>

            <!-- -->
    </div>      
</div>

<!--modal -->

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Criar novo projeto</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
            <form id='newWork' method='POST' action="<?=Env::getURL().'/addnew';?>" enctype="multipart/form-data">
                <div class="mb-3 pl-3 pr-3">
                    <input type='hidden' id='token' name='token' value="<?=md5(time());?>">
                    <input type='hidden' id='groupID' name='groupID' value="<?=@$_SESSION['groupID'];?>">

                    <label for="title">Atribuido a:</label>
                    <select class="form-select mb-3" required  id='atribuido' name='atribuido'>
                        <?php
                             for($i=0; $i< sizeof($group); $i++)
                             {
                                if($_SESSION['name']==$group[$i]['name'])
                                {
                                    echo '<option value="'.$group[$i]['id'].'" selected>'.$group[$i]['nome'].'</option>';
                                }
                                else
                                {
                                    echo '<option value="'.$group[$i]['id'].'">'.$group[$i]['nome'].'</option>';
                                }
                             }
                        ?>                      
                    </select>
                </div>
                <div class="mb-3 pl-3 pr-3">
                    <label for="title">Titulo:</label>
                    <input type="text" class="form-control" id="title" maxlenght="191" name="title" required>
                </div>
                <div class="mb-3 pl-3 pr-3">
                    <label for="tarefa">Tarefa:</label>
                    <input type="text" class="form-control" id="tarefa" maxlenght="191" name="tarefa" required>
                </div>
                <div class="mb-3 pl-3 pr-3">
                    <label for="comentarios">Comentarios:</label>
                    <textarea  class="form-control" id="comentarios" rows="3" cols="50" name="comentarios"></textarea >
                </div>
                <div class="mb-3 pl-3 pr-3">
                    <label for="anexo">Anexo:</label>
                    <input type="file" class="form-control" id="anexo" maxlenght="191" name="taanexorefa" required>
                </div>
            </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" onclick='document.getElementById("newWork").submit();'>Salvar</button>

        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Sair</button>
      </div>

    </div>
  </div>
</div>

<!-- partial -->
<!-- <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js'></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.0/spectrum.min.js'></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script  src="<?php echo Env::getAssets(); ?>/script.js"></script>
<script type='text/javascript'>
$('#color').spectrum({
    color: "#f00",
    change: function(color) {
        $("#label").text("change called: " + color.toHexString());
    }
});
</script>
<script>
        window.onload=  setTimeout(function()
        { 
            const flask = document.getElementById('flask');
            if(flask != undefined)
            {
                flask.style.display="none";
            }
        },
        5600);

        function getUser(id)
        {
           
        }
</script>
</body>
</html>
