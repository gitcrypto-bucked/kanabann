<?php
declare(strict_types=1);
session_start();

use route\Router;
use request\Requisition;

require_once('config/Env.php');

require_once('vendor/autoload.php');

$route = new Router();
$req = new Requisition();

$route->setNamespace('\app\Controller');

$route->get('/',"Home@indexPage");

$route->get('/login',"UserController@loginPage");

$route->post('/login', function() use($req){
    $req->handle($req::CALL, '\app\Controller\UserController@userLogin', $_REQUEST);
});

$route->get('/dash',"KanbanController@dashPage");

$route->post('/addnew','KanbanController@newTask');

$route->post('/update','KanbanController@updateTask');

$route->get('/logout', 'UserController@logout');


$route->run();

define('APP_START', microtime(true));

?>