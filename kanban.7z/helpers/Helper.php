<?php


namespace helpers;
date_default_timezone_set('America/Sao_Paulo');

namespace helpers;

class Helper
{
    public static function greetings() 
    {
        date_default_timezone_set('America/Sao_Paulo');
        $hora = date('H');
        if( $hora >= 6 && $hora <= 12 )
        {
            echo 'Bom dia, '; ;
        }
        else if ( $hora > 12 && $hora <=18  )
        {
            echo 'Boa tarde, '; ;
        }
        else
        {
            echo 'Boa noite, '; ;
        }
    }
}